/*


1.本地路径---

QLPreviewController正常展示 pdf, doc, docx
wkwebview正常展示 pdf, doc, docx
rn-webview正常展示 pdf, doc, docx

2.远程路径---  

1）下载链接

rn-webview 和 wkwebview  --- 服务器繁忙
QLPreviewController ---------No such file or directory
                    ---------issue sandbox extension com.apple.quicklook.readonly for


2）接口返回的url

rn-webview 和 wkwebview  --- 服务器繁忙
QLPreviewController ---------No such file or directory
                    ---------issue sandbox extension com.apple.quicklook.readonly for


原因：1.数据库链接问题。2.流程不对，是不是需要先下载到本地？


3.doc文件不能上传
4.反馈进度接口？
5.反馈信息红点


pod版本
pod源
rn升级0.6遇到的坑

513902198810099331

15982285748

1251748896@qq.com

jh20180510



"appApi":"http://192.168.1.159:38000",


1.货源详情、运单详情、承运单详情当中展示合同，用不同的接口？且用webview来展示？
2.保存货源之后，再来一单
3.本地预览？只有ID、怎么查看合同呢？
3.1.司机财险cell，依赖后端配置


4.引入ios的文件选择库
5.意见反馈ui


console.log('RNFileSelector == ',RNFileSelector);

callback(@[@(0),@(0),@"",@"",@"",@"",@"",@"",@""]);

主线、41.20、41.11、41.10 --- 司机端
主线、41.20、41.11、41.10 --- 物流端

pod repo remove trunk
Removing spec repo `trunk`
pod install 
[!] Unable to find a specification for `React-RCTVibration (= 0.61.5)` depended upon by `React`

You have either:
 * out-of-date source repos which you can update with `pod repo update` or with `pod install --repo-update`.
 * mistyped the name or version.
 * not added the source repo that hosts the Podspec to your Podfile.

pod install --repo-update



if (item.consignmentId === '39f4fb68-0699-c183-3aa4-695a0e81ec6a') {
            console.log('type = ',type);
            console.log('UpdateConsignmentToCarrierBackout = ',GetUserAppLimitStore.UpdateConsignmentToCarrierBackout);
            console.log('revocable = ',revocable);
        }

4-9(清明最后一天)
下周末，资阳

申请邓白氏：5～14天，
拿到邓白氏号码之后，需要：5～14天才能使用
提交企业信息：5天之内有结果
然后交钱，立即生效
所以，申请一个开发者账号
最快13天，最慢35天

530006634@qq.com   密码：Huochaoduo168

稳定3.40.11物流端


1.调研显示本地文件和网络文件的方法。
2.优化电子合同显示逻辑。
3.调试反馈列表接口，以及数据展示。

无感冒发烧咳嗽等症状

广西壮族自治区-崇左市-宁明县： 


			"id": "39f4374f-276c-62c0-367e-cb86055cf795",
			"billCode": "YD2003290001",
			"trackKey": "桂AW3199",
			"orderDate": "2020-03-29 15:12:17",
			"evaluationStatus": "unevaluated",
			"evaluationStatus_Text": "未评价",
			"sourceOrderId": "39f436cc-9e24-d31e-a23c-a0c7570c228b",
			"isShipperDirected": false,
			"allowReAcceptance": false,
			"deliveryName": "广西祥盛木业有限责任公司",
			"deliveryArea": "广西壮族自治区-崇左市-宁明县",
			"deliveryAddress": "崇左市宁明县广西祥盛木业有限责任公司",
			"deliveryContacts": "莫潇",
			"deliveryTel": "13877127798",
			"deliveryDistance": "未获取到定位",
			"receivingDistance": "705.77KM",
			"unitType": "ton",
			"unitType_Text": "吨",
			"goodsPrice": null,
			"goodsTotal": null,
			"receivingName": "广州欧派集成家居有限公司",
			"receivingArea": "广东省-广州市-白云区",
			"receivingAddress": "佛山市三水区乐平镇范湖开发区（粤山）",
			"receivingContacts": "谢佳明",
			"receivingTel": "13927299144",
			"carrierName": "广西联帮盛物流科技有限公司",
			"carrierTel": "19968125727",
			"carrierContacts": "邹洪亮",
			"shipperName": "广西粮运运输有限公司",
			"statusTime": "2020-05-15 11:16:03",
			"statusContent": "司机已完成装车【实装:2吨】",
			"status": "onRoad",
			"status_Text": "运输中",
			"goodsName": "18E0优等",
			"loadingAmount": "2",
			"acceptanceAmount": null,
			"planQty": "20",
			"price": "120",
			"priceUnit": "ton",
			"priceUnit_Text": "元/吨",
			"comment": null,
			"summary": "",
			"lossRate": "0",
			"lossUnit": "milli",
			"lossUnit_Text": "‰",
			"lossRate_Text": "0‰",
			"carTypeName": null,
			"carLength": null,
			"axisNumber": null,
			"capacity": null,
			"deliveryTime": null,
			"receivingTime": null,
			"payWay": "none",
			"payWay_Text": "未指定",
			"agreementStatus": "unuse",
			"agreementStatus_Text": "未用合同"
		}

无感冒咳嗽发烧等症状


怎么设置最低购买数量

好未来运司机端---设计重复

兖矿智慧司机端---需要演示视频

旺旺运司机端---账号无数据

origin

logistics-dev

注意！！！！！登录方式，请选择验证码登录，验证码：1234

gitlab 账号密码： jiangbo 00000000


升级cocoapod sudo gem update --system

版权：成都好伙伴网络科技有限公司

描述：
+86 13980803288
13980803288@qq.com
 
版权：成都市好伙伴软件发展有限公司
 
描述：
+86 13980803288
admin@huochaoduo.com

主线司机端---和小程序司机端---功能差异---包含bug


DEBUG

./gradlew assemblehcdtestDebug
./gradlew assemblehcdlineDebug
adb install app/build/outputs/apk/hcdtest/debug/app-hcdtest-debug.apk

./gradlew assemblehcdlineRelease
./gradlew assemblehcdtestRelease

./gradlew clean // 清理打包缓存

npm run dev:weapp
npm run dev:h5


5.
1.cd到安卓目录下
2.执行打包命令 ./gradlew assemblehcdtestDebug
3.打包完成后，执行adb install app/build/outputs/apk/（安装app到链接的手机）。
例如：adb install app/build/outputs/apk/hcdtest/debug/app-hcdtest-debug.apk

完成时候，cd到rn的packjson目录，执行npm start 
4.adb reverse tcp:8081 tcp:8081（把手机网络和手机网络同步）平时：该命令在任何目录下执行 ，都是可以的。
5.app启动过程有可能会卡住，重启app就可以了。
6.ok 另外，附带一个模拟 摇一摇reload的命令：adb shell input keyevent  82 (该命令在rn的安卓工程目录下执行)


牌照--出现主屏幕的问题
android:theme="@style/AppTheme"
android:theme="@style/Theme.AppCompat.Light.NoActionBar"

RCTWKWebViewDelegate

 lib 文件夹的路径
 /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS.sdk/usr/lib/libstdc++.6.0.9.tbd 
 

************************************************************
 1.计划！ 目标 （熟练git，svn的各种用法，不能仅仅局限在提交代码就完了）

 2.执行！坚持执行！（做事情！不能拖！）

 3.工作方面需要注意的点：
 （1）把自己作为一个测试没去思考，可能出现的异常！多思考！
 （2）提交代码前，一定review自己的代码！！！！！！避免低级bug！！！！！
 （3）多看官方文档！！！！反复看
 （4）做事情之前，理清楚需求！多考虑设计模式！
 （4）任务只在指定的分支开发。不要迁移到未指定的分支！！！！
照片用于认证和系统审核

3.40.10版 已经提交审核，低版本的上架任务退回

倾诉的重要性

终究要学会坚强，而不是选择逃避压力。

没有经历过高复的高中，不算是真正经历了高中。这句话稍显片面，但一定有他的道理。

快乐的真谛，多不在得时欣喜，而在失后坦然...
人生有两件事最重要：一是要学会选择，二是要学会放弃。我们的命运，取决于自己的选择。所有的...
再好的东西，你抓得太紧，终会累的。(自己累，对方也累。我门就是我太在乎了)
人之所以快乐，并不是因为他拥有的多，而是因为计较的少。
人生中出现的一切，都无法拥有，只能经历。深知这一点的人，就会懂得：无所谓失去，只是经过而已；无所谓失败，只是经验而已。用一颗浏览的心，去看待人生，一切的得与失、隐与显，都是风景与风情。
聚散乃是长情，离合亦是机缘

一路看下去，偶尔能找到自己性格脾气发展至今的一些源头。
明白自己为何会成为现在这样，真正认识自己，了解自己。

所有的压力都表现在：
对自己的不自信、某些地方的自卑、对生活的焦虑、对亲密关系的不信任（或过度谨慎）、对感情缺乏安全感...

很多人都能意识到问题的问在，却找不到根源。
错误的以为：“不自信”，“缺少安全感”...这就是自己的性格特点，是天生的，不能改变。

被忽视的感受挤压在心里，久而久之，越积越多。以为时间可以治愈一切。
可实际上，等到自己有机会发泄出来的时候，那些挤压在内心的不愉快，会慢慢爆发出来，变成我们的情绪，影响我们的生活。

除了，无话不谈的知己。

前几天我相亲了。
我第一次：不认真。
不太认真，随便相亲的，没有做任何准备，真的只是随便碰个面。
我几乎全程，负能量，讲自己跟别的女生如何尬聊，如何没底线...。
一直面无表情，哈哈，估计之后会成为她嘴里的"奇葩相亲对象"之一。
起初，我的情绪很糟糕，后来看着她无语的表情，我心里感觉莫名的舒服。


年轻的时候不屑于倾诉，感觉自己桀骜不羁，天地苍茫我独行，喜欢与书本文字对谈。
年纪渐长，发现自己心机太浅而心眼太实，害怕受伤害儿不愿意倾诉。

愿你自强到无需有人宠有人惯
但却仍然幸运到有人宠有人惯

盼携手终老，愿与子同袍

我自己想了很多话，写到最后。发现都是在围绕一个意思。


和一个人走向婚姻，就需要两个感觉

安全感和归属感

安全感, 是确定对方不会离开自己
归属感, 是确定自己不会离开对方
*/
#pragma mark - UIDocumentPickerDelegate
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    //获取授权
    BOOL fileUrlAuthozied = [urls.firstObject startAccessingSecurityScopedResource];
    if (fileUrlAuthozied) {
        //通过文件协调工具来得到新的文件地址，以此得到文件保护功能
        NSFileCoordinator *fileCoordinator = [[NSFileCoordinator alloc] init];
        NSError *error;
        
        [fileCoordinator coordinateReadingItemAtURL:urls.firstObject options:0 error:&error byAccessor:^(NSURL *newURL) {
            //读取文件
            NSString *fileName = [newURL lastPathComponent];
            NSError *error = nil;
            NSData *fileData = [NSData dataWithContentsOfURL:newURL options:NSDataReadingMappedIfSafe error:&error];
            if (error) {
                //读取出错
            } else {
//              NSLog(@"上传===%@",urls);
                NSLog(@"上传===%@",newURL);
              NSLog(@"上传===%@",fileData);
              float fileSize = fileData.length / 1000000.0 ;
              NSLog(@"fileSize = %.4f",fileSize);
              
              if (fileSize > 10.0) {
                return;
              }
              
              NSString *type = [self fileTyeString:fileName];
              
              HcdFileManager *manager = [HcdFileManager shareInstance];
              if (manager.callback) {
                NSDictionary *dic = @{
                  @"path": newURL.absoluteString,
                  @"type": type,
                  @"name": fileName
                };
                manager.callback(@[dic]);
              }
            }
            UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
            [window.rootViewController dismissViewControllerAnimated:YES completion:nil];
        }];
        [urls.firstObject stopAccessingSecurityScopedResource];
    } else {
        //授权失败
    }
}

- (NSString *)fileTyeString:(NSString *)fileName {
  NSArray *array = [fileName componentsSeparatedByString:@"."];
  if (array.count > 0) {
    NSString *type = [NSString stringWithFormat:@".%@",[array lastObject]];
    return type;
  }
  NSLog(@"文件类型获取失败");
  return @"";
}

- (NSString *)fileType:(NSString *)path {
  NSURL *url = [NSURL URLWithString:path];
  NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
  
  dispatch_semaphore_t sp = dispatch_semaphore_create(0);
  __block NSString *type = @"";
  NSURLSession *session = [NSURLSession sharedSession];
  NSURLSessionDataTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
    dispatch_semaphore_signal(sp);
    if (error) {
      NSLog(@"文件类型获取失败");
    } else {
      NSLog(@"文件类型 = %@",response.MIMEType);
      type = response.MIMEType;
    }
  }];
  [task resume];
  dispatch_semaphore_wait(sp, DISPATCH_TIME_FOREVER);
  
  if ([type isEqualToString:@"application/msword"]) {
    return @".doc";
  }
  if ([type isEqualToString:@"application/pdf"]) {
    return @".pdf";
  }
  if ([type isEqualToString:@"application/msword"]) {
    return @".doc";
  }
  
  return type;
}

- (NSString *)fileTypeASICCode:(NSData *)fileData {
  if (fileData.length < 2) {
    return nil;
  }
  int char1 = 0 ,char2 =0 ; //必须这样初始化
  [fileData getBytes:&char1 range:NSMakeRange(0, 1)];

  [fileData getBytes:&char2 range:NSMakeRange(1, 1)];

  NSString *numStr = [NSString stringWithFormat:@"%i%i",char1,char2];
  return numStr;
}

-(NSString *)getMIMETypeWithCAPIAtFilePath:(NSString *)path
{
  
   if (![[[NSFileManager alloc] init] fileExistsAtPath:path]) {
     NSLog(@"文件不存在");
       return nil;
   } else {
     
   }

    CFStringRef UTI = UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension, (__bridge CFStringRef)[path pathExtension], NULL);
    CFStringRef MIMEType = UTTypeCopyPreferredTagWithClass (UTI, kUTTagClassMIMEType);
  NSLog(@"MIMEType === %@",MIMEType);
    CFRelease(UTI);
    if (!MIMEType) {
        return @"application/octet-stream";
    }
    return (__bridge NSString *)(MIMEType);
}